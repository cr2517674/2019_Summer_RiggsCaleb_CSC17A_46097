/*
 *            PROGRAMMER: Caleb Riggs
 *         PROBLEM TITLE: Celsius to Fahrenheit
 *    PROBLEM DEFINITION: Program to convert Celsius to Fahrenheit
 *                  DATE: 6/18/2019
 *     SYSTEM - HARDWARE: Intel i7
 *            - SOFTWARE: MS Windows 10, Netbeans IDE 8.0.2
 *         Input Devices: Keyboard
 *        Output Devices: Terminal screen                                                            
 */

#include <iostream>

using namespace std;

// main function here
int main()
{
    double tempF;
    double tempC;
    
    // Display program purpose.
    cout << "This program is designed to convert Celsius to Fahrenheit.\n";
    
    // Prompt the user to enter a value for temp in Celsius.
    cout << "Please enter the temperature in Celsius: ";
    cin >> tempC;
    
    tempF = (1.8 * tempC) + 32;
    cout << "The temp in Fahrenheit is... " << endl;
    cout << tempF << " degrees";
		
    return 0;
}